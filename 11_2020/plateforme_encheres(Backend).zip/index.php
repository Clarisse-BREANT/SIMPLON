<?php
chdir("encheres");
include "./index.php"
?>